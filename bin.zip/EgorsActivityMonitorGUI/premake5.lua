workspace "EgorsActivityMonitor"
    architecture "x64"
    startproject "EgorsActivityMonitorGUI"

    configurations { "Debug", "Release" }

outputdir = "%{cfg.buildcfg}-%{cfg.system}-%{cfg.architecture}"

IncludeDir = {}
IncludeDir["ImGui"] = "ThirdParty/imgui"
IncludeDir["ImGuiBackend"] = "ThirdParty/imgui/backends"
IncludeDir["spdlog"] = "ThirdParty/spdlog/include"

project "EgorsActivityMonitorGUI"
    location "EgorsActivityMonitorGUI"
    kind "WindowedApp"
    language "C++"
    cppdialect "C++17"
    staticruntime "on"

    targetdir ("bin/" .. outputdir .. "/%{prj.name}")
    objdir ("bin-int/" .. outputdir .. "/%{prj.name}")

files
{
    "%{prj.name}/src/**.h",
    "%{prj.name}/src/**.cpp",
    "ThirdParty/imgui/backends/imgui_impl_dx11.cpp",
    "ThirdParty/imgui/backends/imgui_impl_win32.cpp",
    "ThirdParty/imgui/*.cpp"
}

includedirs
{
    "%{prj.name}/src",
    "ThirdParty/imgui",
    "ThirdParty/imgui/backends",
    "ThirdParty/spdlog/include"
}

    defines 
    { 
        "PLATFORM_WINDOWS",
        "IMGUI_IMPL_WIN32"
    }

    links
    {
        "d3d11.lib",
        "dxgi.lib",
        "dxguid.lib",
        "kernel32.lib",
        "user32.lib",
        "gdi32.lib",
        "winspool.lib",
        "comdlg32.lib",
        "advapi32.lib",
        "shell32.lib",
        "ole32.lib",
        "oleaut32.lib",
        "uuid.lib",
        "odbc32.lib",
        "odbccp32.lib"
    }

    filter "system:windows"
        systemversion "latest"
        characterset "Unicode"
        buildoptions { "/utf-8" }

    filter "configurations:Debug"
        defines { "DEBUG" }
        runtime "Debug"
        symbols "on"

    filter "configurations:Release"
        defines { "RELEASE" }
        runtime "Release"
        optimize "on"